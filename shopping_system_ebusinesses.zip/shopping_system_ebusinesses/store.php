<?php
include 'header.php';
?>
    <br>
    <div class="main main-raised">
        <div class="section">
			<div class="container">
				<div class="row">
					<div id="aside" class="col-md-3">
                        <div id="get_category">
                        </div>

						<div class="aside">
						</div>

						<div id="get_brand">
				        </div>
					</div>
					<div id="store" class="col-md-9">
						<div class="row" id="product-row">
						    <div class="col-md-12 col-xs-12" id="product_msg">
					        </div>

							<div id="get_product">
						    </div>

						</div>
						<div class="store-filter clearfix">
							<ul class="store-pagination" id="pageno">
								<li ><a class="active" href="#aside">1</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
</div>
<?php
include "footer.php";
?>