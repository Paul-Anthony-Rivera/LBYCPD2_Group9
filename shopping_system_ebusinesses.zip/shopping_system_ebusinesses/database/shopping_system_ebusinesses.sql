-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2021 at 12:09 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping_system_ebusinesses`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getcat` (IN `cid` INT)  SELECT * FROM categories WHERE cat_id=cid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '1234567879');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'AMD'),
(2, 'Samsung'),
(3, 'Apple'),
(4, 'Logitech'),
(5, 'Acer'),
(6, 'HyperX'),
(7, 'Intel'),
(8, 'AiDeLai'),
(9, 'Heng De');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(155, 1, '::1', 27, 1),
(157, 1, '::1', -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Electronics'),
(2, 'Health Wear');

-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(1, 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 12, 'Jonathan Lee', 'jonathanlee9942@gmail.com', 'roxas street', 'koronadal city', 'asd', 123, 'jonathan lee', '123456789', '12/23', 3, 77000, 123),
(2, 26, 'jon lee', 'jonathanlee9942@gmail.com', 'asd', 'asd', 'asd', 123, 'jon lee', '123456789', '12/23', 1, 40000, 123),
(3, 27, 'paul rivera', 'paul_rivera@dlsu.edu.ph', 'asd', 'asd', 'asd', 123, 'paul rivera', '123456789', '12/24', 1, 25000, 123),
(4, 27, 'paul rivera', 'paul_rivera@dlsu.edu.ph', 'asd', 'asd', 'asd', 123, 'paul rivera', '123456789', '12/12', 1, 25000, 12),
(5, 27, 'paul rivera', 'paul_rivera@dlsu.edu.ph', 'asd', 'asd', '', 123, 'paul rivera', '123456789', '12/30', 1, 25000, 123),
(6, 27, 'paul rivera', 'paul_rivera@dlsu.edu.ph', 'asd', 'asd', '', 123, 'pol', '1234566788', '12/23', 1, 25000, 123),
(7, 27, 'paul rivera', 'paul_rivera@dlsu.edu.ph', 'asd', 'asd', '', 123, 'pol', '12345676787', '12/26', 1, 25000, 123),
(8, 27, 'paul rivera', 'paul_rivera@dlsu.edu.ph', 'asd', 'asd', '', 123, 'asda', '213556667', '12/23', 1, 25000, 213),
(9, 28, 'Ana Illahi', 'ana.illahi@dlsu.edu.ph', 'Sta Rosa ', 'Laguna', '', 4026, 'Ana Illahi', '1234567891234567', '02/25', 2, 45000, 27);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(91, 2, 20, 1, 40000),
(92, 3, 1, 1, 25000),
(93, 4, 1, 1, 25000),
(94, 5, 1, 1, 25000),
(95, 6, 1, 1, 25000),
(96, 7, 1, 1, 25000),
(97, 8, 1, 1, 25000),
(98, 9, 1, 1, 25000),
(99, 9, 2, 1, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  `product_quantity` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`, `product_quantity`) VALUES
(1, 1, 1, 'AMD Ryzen  9', 25000, 'amd ryzen 9 2020', 'ryzen_9.jpg', 'amd r9 processor', 10),
(2, 1, 1, 'AMD Ryzen  7', 20000, 'amd ryzen 7 2020', 'ryzen_7.jpg', 'amd r7 processor', 10),
(3, 1, 1, 'AMD Ryzen 5', 12000, 'amd ryzen 5 2020', 'ryzen_5.jpg', 'amd r5 processor', 10),
(4, 1, 5, 'Acer Nitro 5', 50000, 'acer nitro 5 1t ssd 16gb ram', 'acer_nitro5.jpg', 'acer nitro 5 laptop', 10),
(5, 1, 5, 'Acer Spin 5', 40000, 'acer spin 5 500gb ssd 8gb ram', 'acer_spin5.jpg', 'acer spin 5 laptop', 10),
(6, 1, 5, 'Acer Aspire 3', 35000, 'acer aspire 3 256gb 4gb ram ', 'acer_aspire3.jpg', 'acer aspire 3 laptop', 10),
(7, 1, 5, 'Acer Predator', 80000, 'acer predator 2tb hdd 32gb ram', 'acer_predator.jpg', 'acer predator laptop', 10),
(8, 1, 5, 'Acer Swift 3', 35000, 'acer swift 3 256gb ssd 4gb ram', 'acer_swift3.jpg', 'acer swift 3 laptop', 10),
(9, 2, 8, 'AiDeLai Facemask', 250, 'aidelai non-surgical facemask', 'aidelai_facemask.jpg', 'aidelai facemask', 10),
(10, 2, 8, 'AiDeLai KN95', 300, 'aidelai kn95', 'aidelai_kn95.jpg', 'aidelai kn95', 10),
(11, 2, 8, 'AiDeLai N95', 600, 'aidelai n95', 'aidelai_n95.jpg', 'aidelai n95', 10),
(12, 2, 9, 'Heng De Faceshield', 50, 'hengde faceshield', 'hengde_faceshield.jpg', 'hengde faceshield ', 10),
(13, 1, 6, 'HyperX Mechanical Keyboard', 5000, 'hyperx full-sized mechanical keyboard  ', 'hyperx_keyboard.jpg', 'hyperx m keyboard', 10),
(14, 1, 3, 'Apple Macbook Pro', 75000, 'apple macbook pre 2020', 'apple_macbook.jpg', 'apple macbook pro', 10),
(15, 1, 7, 'Intel Core i3', 8000, 'intel core i3 processor', 'intel_i3.jpg', 'intel i3 processor', 10),
(16, 1, 7, 'Intel Core i5', 12000, 'intel core i5 processor', 'intel_i5.jpg', 'intel 15 processor', 10),
(17, 1, 7, 'Intel Core i9', 25000, 'intel core i9 processor', 'intel_i9.jpg', 'intel i9 processor', 10),
(18, 1, 7, 'Intel Core i7', 18000, 'intel core i7 processor', 'intel_i7.jpg', 'intel i7 processor', 10),
(19, 1, 3, 'Apple Iphone X', 35000, 'apple iphone x 256gb', 'iphone10.jpg', 'iphone10', 10),
(20, 1, 3, 'Apple Iphone 11', 40000, 'apple iphone 11 256gb', 'iphone11.jpg', 'iphone11', 10),
(21, 1, 3, 'Apple Iphone 12', 50000, 'apple iphone 12 256gb', 'iphone12.jpg', 'iphone12', 10),
(22, 1, 3, 'Apple Watch s6', 20000, 'apple watch s6 ', 'iwatch_s6.jpg', 'apple watch', 10),
(23, 1, 4, 'Logitech M100', 2000, 'logitech m100 mouse', 'logitech_m100.jpg', 'logitech m100 mouse', 10),
(24, 1, 4, 'Logitech M535', 3000, 'logitech m535 mouse', 'logitech_m535.jpg', 'logitech m535 mouse', 10),
(25, 1, 4, 'Logitech MX Anywhere 3', 2500, 'logitech mx anywhere 3 mouse', 'logitech_mx_anywhere3.jpg', 'logitech mx anywhere 3 mouse', 10),
(26, 1, 4, 'Logitech MX Master 3', 5000, 'logitech mx master 3 mouse', 'logitech_mx_master3.jpg', 'logitech mx master 3 mouse', 10),
(27, 1, 4, 'Logitech Pebble M350', 3000, 'logitech mx anywhere 3 mouse', 'logitech_mx_anywhere3.jpg', 'logitech mx anywhere 3 mouse', 10),
(28, 1, 2, 'Samsung Note 10', 30000, 'samsung note 10 phone', 'samsung_n10.jpg', 'samsung n10 phone ', 10),
(29, 1, 2, 'Samsung Note 20', 50000, 'samsung note 20 phone ', 'samsung_n20.jpg', 'samsung n20 phone', 10),
(30, 1, 2, 'Samsung S20 ', 40000, 'samsung s20 phone', 'samsung_s20.jpg', 'samsung s20 phone', 10),
(31, 1, 2, 'Samsung S21', 60000, 'samsung s21 phone', 'samsung_s21.jpg', 'samsung s20 phone', 10),
(32, 1, 2, 'Samsung watch', 15000, 'samsung watch', 'samsung_watch.jpg', 'samsung s20 phone', 10);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(26, 'jon', 'lee', 'jonathanlee9942@gmail.com', '123456789', '0911111111', 'asd', '123'),
(27, 'paul', 'rivera', 'paul_rivera@dlsu.edu.ph', '123456789', '0922222222', 'asd', 'asd'),
(28, 'Ana', 'Illahi', 'ana.illahi@dlsu.edu.ph', '12345Ana!', '0968855437', 'Sta Rosa ', 'Laguna');

--
-- Triggers `user_info`
--
DELIMITER $$
CREATE TRIGGER `after_user_info_insert` AFTER INSERT ON `user_info` FOR EACH ROW BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_info_backup`
--

CREATE TABLE `user_info_backup` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(26, 'jon', 'lee', 'jonathanlee9942@gmail.com', '123456789', '0911111111', 'asd', '123'),
(27, 'paul', 'rivera', 'paul_rivera@dlsu.edu.ph', '123456789', '0922222222', 'asd', 'asd'),
(28, 'Ana', 'Illahi', 'ana.illahi@dlsu.edu.ph', '12345Ana!', '0968855437', 'Sta Rosa ', 'Laguna');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
