<?php
include "header.php";
?>
    <br>
    <div class="main main-raised">
        <div class="section">
            <div class="container">
                <h3>Developers' Contact Info</h3><br>
                <img src="img/developer1.jpg" width="135" height="160"><br>
                <label>Name: Paul Anthony Rivera</label><br>
                <label>E-mail Address: paul_rivera@dlsu.edu.ph</label><br>
                <label>Mobile Number: 09111111111</label><br>
                <br>
                <img src="img/developer2.jpeg" width="135" height="160"><br>
                <label>Name: Jonathan Lee</label><br>
                <label>E-mail Address: jonathan_lee@dlsu.edu.ph</label><br>
                <label>Mobile Number: 09222222222</label><br>
            </div>
        </div>
    </div>
<?php
include "footer.php";
?>