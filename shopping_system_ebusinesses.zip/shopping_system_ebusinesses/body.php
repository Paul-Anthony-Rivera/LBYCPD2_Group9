<br>
<div class="main main-raised">
    <div class="container mainn-raised" style="width:100%" >
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="item active">
                    <img src="img/carousel1.jpg" alt="Los Angeles" style="width:100%;">
                </div>
                <div class="item">
                    <img src="img/carousel2.png" alt="Los Angeles" style="width:100%;">
                </div>
                <div class="item">
                    <img src="img/carousel3.jpg" alt="New York" style="width:100%;">
                </div>
                <div class="item">
                    <img src="img/carousel4.jpg" alt="New York" style="width:100%;">
                </div>
                <div class="item">
                    <img src="img/carousel5.jpg" alt="New York" style="width:100%;">
                </div>
                <div class="item">
                    <img src="img/carousel6.jpg" alt="New York" style="width:100%;">
                </div>
            </div>

            <a class="left carousel-control" href="#myCarousel" data-slide="prev"></a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next"></a>
        </div>
    </div>

    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h3 class="title">On Sale</h3>
                    </div>
                </div>
                <div class="col-md-12 mainn mainn-raised">
                    <div class="row">
                        <div class="products-tabs">
                            <div id="tab1" class="tab-pane active">
                                <div class="products-slick" data-nav="#slick-nav-1" >
                                    <?php
                                    include 'db.php';

                                    $product_query = "SELECT * FROM products,categories WHERE product_cat=cat_id AND product_id BETWEEN 70 AND 75";
                                    $run_query = mysqli_query($con,$product_query);
                                    if(mysqli_num_rows($run_query) > 0){
                                        while($row = mysqli_fetch_array($run_query)){
                                            $pro_id    = $row['product_id'];
                                            $pro_cat   = $row['product_cat'];
                                            $pro_brand = $row['product_brand'];
                                            $pro_title = $row['product_title'];
                                            $pro_price = $row['product_price'];
                                            $pro_image = $row['product_image'];
                                            $cat_name = $row["cat_title"];

                                            echo "
								                <div class='product'>
									            <a href='product.php?p=$pro_id'>
									            <div class='product-img'>
										            <img src='product_images/$pro_image' style='max-height: 170px;' alt=''>
										            <div class='product-label'>
											            <span class='sale'>-30%</span>
										            </div>
									            </div></a>
									            <div class='product-body'>
										            <p class='product-category'>$cat_name</p>
										            <h3 class='product-name header-cart-item-name'><a href='product.php?p=$pro_id'>$pro_title</a></h3>
										            <h4 class='product-price header-cart-item-info'>₱$pro_price<del class='product-old-price'>₱990.00</del></h4>
										            <button pid='$pro_id' id='product' class='add-to-cart-btn block2-btn-towishlist' href='#'>
									                <i class='fa fa-shopping-cart'></i> add to cart</button>
									            </div>
                                            </div>
                                            ";
                                            };
                                        }
                                        ?>
									</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

       <br><br><br>
       <div class="container">
           <h3 class="title">About Us</h3>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;We are DLSU students that aims to help E-businesses by creating a free website for them to help
                    them easily manage their business and help them be more efficient in handling all the customers
                    that are in need of their products/services. Our aim is to create an online shopping system in which
                    the sellers can input details about the products they are selling such as the image, price, available
                    stocks, etc., while buyers can select the items they want to order. The reason for creating this project
                    is because the developers want to help the ones who are in need of an online business website where they
                    can have a quicker buy and sell transaction with easy navigation of items and a more user-friendly interface.
                    As we all know, technologies play an important role in our generation, and this means technology does
                    nothing but improve from time to time. Nowadays, technologies can almost be seen everywhere we go. One
                    example of a technological system that is widely used is the internet. The Internet keeps us, in a way,
                    connected to the world. From searching for things to gain information and knowledge, to communications,
                    and connectivity with other people far from you, to watch entertainment such as watching movies, videos,
                    play games, and even to business purposes such as selling products, buying, paying bills, and sending moneys,
                    a lot of things can be done with the use of internet. Focusing on one of the aspects/results of the internet
                    is online business or ecommerce wherein buying and selling of products or services can be made faster compared
                    to traditional or physical businesses. Traditional business has already been established long before the internet
                    was invented, thus it was practiced and used by everyone in order to trade, sell, buy items or do other transactions.
                    Especially now that most of the world has access to the internet, online business can do more things a lot faster
                    compared to physical stores with no geographical limitations, easier way to gain more customers, have lower
                    cost of investment, and easily manage inventory. This project will not only help the clients of the developers
                    to have a usable online shopping website, but also for the developers to improve their programming skills and as
                    well be more practiced and engaged in the real world.
                </p>
       </div>
       <br><br><br>
   </div>
		