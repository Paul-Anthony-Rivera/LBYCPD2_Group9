<?php
include "header.php";
?>
    <br>
    <div class="main main-raised">
        <div class="section">
            <div class="container">
                <h3>About Seller</h3>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                    culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur
                    adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                    minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                    pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit
                    anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                    ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                    voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet,
                    consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                    enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    onsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                    nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                    mollit anim id est laborum.</p>
                <br>
                <h3>About Developers</h3>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;We are DLSU students that aims to help E-businesses by creating a free website for them to help
                    them easily manage their business and help them be more efficient in handling all the customers
                    that are in need of their products/services. Our aim is to create an online shopping system in which
                    the sellers can input details about the products they are selling such as the image, price, available
                    stocks, etc., while buyers can select the items they want to order. The reason for creating this project
                    is because the developers want to help the ones who are in need of an online business website where they
                    can have a quicker buy and sell transaction with easy navigation of items and a more user-friendly interface.
                    As we all know, technologies play an important role in our generation, and this means technology does
                    nothing but improve from time to time. Nowadays, technologies can almost be seen everywhere we go. One
                    example of a technological system that is widely used is the internet. The Internet keeps us, in a way,
                    connected to the world. From searching for things to gain information and knowledge, to communications,
                    and connectivity with other people far from you, to watch entertainment such as watching movies, videos,
                    play games, and even to business purposes such as selling products, buying, paying bills, and sending moneys,
                    a lot of things can be done with the use of internet. Focusing on one of the aspects/results of the internet
                    is online business or ecommerce wherein buying and selling of products or services can be made faster compared
                    to traditional or physical businesses. Traditional business has already been established long before the internet
                    was invented, thus it was practiced and used by everyone in order to trade, sell, buy items or do other transactions.
                    Especially now that most of the world has access to the internet, online business can do more things a lot faster
                    compared to physical stores with no geographical limitations, easier way to gain more customers, have lower
                    cost of investment, and easily manage inventory. This project will not only help the clients of the developers
                    to have a usable online shopping website, but also for the developers to improve their programming skills and as
                    well be more practiced and engaged in the real world.
                </p>

            </div>
        </div>
    </div>

<?php
include "footer.php";
?>