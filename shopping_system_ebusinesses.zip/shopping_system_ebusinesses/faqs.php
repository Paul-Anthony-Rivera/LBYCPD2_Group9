<?php
include "header.php";
?>
    <br>
    <div class="main main-raised">
        <div class="section">
            <div class="container">
                <h3><b>Frequently Asked Questions</b></h3><br>
                <h5><b>Manufacturer or Reseller?</b></h5>
                <h5>Answer: Depends on the seller. </h5>
                <br><br>
                <h5><b>Do you offer wholesale price?</b></h5>
                <h5>Answer: No. We only offer retail price. </h5>
                <br><br>
                <h5><b>Do you deliver?</b></h5>
                <h5>Answer: No. We only offer shipping. </h5>
                <br><br>
                <h5><b>When will I get my order?</b></h5>
                <h5>Answer: It depends on your location. For nationwide, it will take approximately 5-7 days. </h5>
            </div>
        </div>
    </div>
<?php
include "footer.php";
?>